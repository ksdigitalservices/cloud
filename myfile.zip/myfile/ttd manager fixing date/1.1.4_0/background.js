chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: {tabId: tab.id},
    files: ["content.js"]
  });
});

// NEW: Listener for keyboard shortcut command
chrome.commands.onCommand.addListener((command, tab) => {
  if (command === "autofill_and_run") {
    // Send a message to the content script in the active tab
    chrome.tabs.sendMessage(tab.id, { action: "runAutofillShortcut" });
  }
});


chrome.commands.onCommand.addListener((command) => {

  if (command === "open_my_url") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.update(tabs[0].id, {
        url: "https://ttdevasthanams.ap.gov.in/spat/slot-booking?flow=spat&flowIdentifier=spat"
      });
    });
  }

});

//auto run at time

// ===== 1. Scheduler =====
function scheduleNextRun() {
  const now = new Date();

  let next = new Date(
    now.getFullYear(),
                      now.getMonth(),
                      16,
                      23,
                      10,
                      5,
                      0
  );

  if (now.getTime() > next.getTime()) {
    next = new Date(
      now.getFullYear(),
                    now.getMonth() + 1,
                    16,
                    23,
                    10,
                    5,
                    0
    );
  }

  const delayInMinutes = (next.getTime() - now.getTime()) / 60000;

  chrome.alarms.create("open_my_url_alarm", {
    delayInMinutes
  });
}


// ===== 2. Alarm handler =====
chrome.alarms.onAlarm.addListener((alarm) => {

  if (alarm.name === "open_my_url_alarm") {

    const url = "https://ttdevasthanams.ap.gov.in/spat/slot-booking?flow=spat&flowIdentifier=spat";

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.update(tabs[0].id, { url });
      } else {
        chrome.tabs.create({ url });
      }
    });

    // reschedule for next month
    scheduleNextRun();
  }
});


// ===== 3. Auto start scheduler =====
chrome.runtime.onInstalled.addListener(() => {
  scheduleNextRun();
});

chrome.runtime.onStartup.addListener(() => {
  scheduleNextRun();
});



// Create a repeating alarm every 10 seconds
chrome.alarms.create("autofill_interval", {
  periodInMinutes: 0.5
});

// Handle the alarm
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "autofill_interval") {
    // Get active tab and send the same message
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "runAutofillShortcut" });
      }
    });
  }
});
