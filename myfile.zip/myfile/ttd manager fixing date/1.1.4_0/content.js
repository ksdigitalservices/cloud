javascript:(function(){
    if(window.__ttdManager){window.__ttdManager.remove();}
    window.__ttdManager=document.createElement("div");
    const wrap=window.__ttdManager;
    const STORAGE_KEY="TTD_PilgrimLists";
    const AUTH_KEY="TTD_Auth";
    // NEW: Key for general extension settings
    const SETTINGS_KEY="TTD_Settings";

    // *** CWS REVIEW BYPASS START (సమీక్షకులకు ఆటోఫిల్ ఫీచర్ ఎక్స్‌పైర్ కాలేదని నిర్ధారిస్తుంది) ***
    const IS_REVIEW_MODE = true;
    // *** CWS REVIEW BYPASS END ***

    let lists=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");
    let auth=JSON.parse(localStorage.getItem(AUTH_KEY)||"{}");
    // Load settings, set defaults
    let settings=JSON.parse(localStorage.getItem(SETTINGS_KEY)||"{}");
    // Removed enableDesktopMenu default/check as it's now always true when logged in.
    if(settings.showLowerToolbar === undefined) settings.showLowerToolbar = true;

    let currentList=null,minimized=true,selectedPlan="30";
    // ===== SLOT CONFIG (GLOBAL) =====
    let selectedDate = "3/4";     // format from td id
    let selectedPeople = "2";     // number as string
    let selectedTime = "0900";    // button value
    // --- Utility Functions ---
    function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
    function setValue(el,val){if(!el)return;let last=el.value;el.value=val;let tr=el._valueTracker;if(tr)tr.setValue(last);el.dispatchEvent(new Event("input",{bubbles:true}));el.dispatchEvent(new Event("change",{bubbles:true}));el.dispatchEvent(new Event("blur",{bubbles:true}));}
    async function pick(el,val){if(!el)return;el.click();await sleep(200);let options=Array.from(document.querySelectorAll('[role="option"],mat-option,li,div,span')).filter(o=>o.innerText&&o.innerText.trim().toLowerCase()===String(val||"").toLowerCase());options[0]?options[0].click():setValue(el,val);}

    let automationRunning = false;

    async function fullBookingFlow(){

        await selectSlotDetailsSkip();

        await sleep(500);

        await autofill();

        await sleep(500);

        await autoContinue();

        await sleep(500);

        await autoContinue();

        await sleep(500);

        await clickPayNow();
    }

    async function runAutomationSafe(){

        if(automationRunning){

            console.log("Automation already running");

            return;
        }

        automationRunning = true;

        try{

            await fullBookingFlow();

        } catch(err){

            console.log("Automation error:", err);

        } finally{

            automationRunning = false;
        }
    }






    // --- Expiry Status Logic & Header Update FIX ---
    function isExpired() {
        // CWS REVIEW BYPASS: Don't allow expiry alerts during review.
        if (IS_REVIEW_MODE) {
            return false;
        }

        return !auth.expiryTimestamp || Date.now() >= auth.expiryTimestamp;
    }

    function getExpiryStatus() {
        if (!auth.expiryTimestamp) {
            return 'Status: Not Active';
        }
        const expiryDate = new Date(auth.expiryTimestamp);
        const now = Date.now();
        if (expiryDate.getTime() > now) {
            const diffTime = Math.abs(expiryDate.getTime() - now);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const dateStr = expiryDate.toLocaleDateString();
            return `Status: Active (${diffDays} days left). Expires on: ${dateStr}`;
        } else {
            return 'Status: EXPIRED! Click renew plan.';
        }
    }

    function updateManagerHeader(container) {
        const expirySpan = container.querySelector("#ttd-expiry-status");
        if (expirySpan) {
            // Show CWS Review Status if bypass is active
            if (IS_REVIEW_MODE) {
                expirySpan.textContent = 'Status: Active (CWS Review Mode)';
                expirySpan.style.color = '#4CAF50';
                expirySpan.style.fontWeight = 'bold';
            } else {
                expirySpan.textContent = getExpiryStatus();
                if (isExpired()) {
                    expirySpan.style.color = '#F44336'; // Red
                    expirySpan.style.fontWeight = 'bold';
                } else {
                    expirySpan.style.color = '#4CAF50'; // Green
                    expirySpan.style.fontWeight = 'bold';
                }
            }
        }
        // Update toolbar visibility based on settings
        const mainControls = container.querySelector("#main-controls");
        const smallControls = container.querySelector("#small-controls");
        if(mainControls) mainControls.style.display = settings.showLowerToolbar ? 'flex' : 'none';
        if(smallControls) smallControls.style.display = settings.showLowerToolbar ? 'flex' : 'none';
    }

    async function selectSlotDetailsSkip(){
        const nameInputs = document.querySelectorAll(
            'input[name="name"], input[formcontrolname="name"], input[name="fname"]'
        );

        if (nameInputs.length > 0) {
            console.log("date skip page so filling")
            return; // exit early
        }
        else{
            console.log("date page so selecting date")
            await selectSlotDetails();
        }
    }

    function getTableData(){

        const managerTable =
        document.querySelector("#ks-manager-table");

        if(!managerTable){

            console.log("Manager table not found");

            return [];
        }

        const rows =
        managerTable.querySelectorAll("tr");

        if(!rows.length){

            console.log("No table rows found");

            return [];
        }

        const data = [];

        rows.forEach(row => {

            const cells = row.querySelectorAll("td");

            if(cells.length < 14) return;

            data.push({
                date: cells[0]?.innerText.trim() || "",
                      people: cells[1]?.innerText.trim() || "",
                      time: cells[2]?.innerText.trim() || "",
                      name: cells[3]?.innerText.trim() || "",
                      age: cells[4]?.innerText.trim() || "",
                      gender: cells[5]?.innerText.trim() || "",
                      aadhar: cells[6]?.innerText.trim() || "",
                      email: cells[7]?.innerText.trim() || "",
                      city: cells[8]?.innerText.trim() || "",
                      state: cells[9]?.innerText.trim() || "",
                      country: cells[10]?.innerText.trim() || "",
                      pincode: cells[11]?.innerText.trim() || "",
                      gotram: cells[12]?.innerText.trim() || "",
                      upi: cells[13]?.innerText.trim() || ""
            });
        });

        return data;
    }

    function getCurrentUpiValue(){

        const tableData = getTableData();

        if(!tableData.length){
            return "";
        }

        return (
            tableData[0].upi || ""
        ).trim();
    }
    // --- End Expiry Status Logic ---
    async function selectSlotDetails(){
        // WAIT FOR PAGE READY
        // WAIT FOR CALENDAR TO RENDER

        for(let i=0;i<5;i++){
            if(document.querySelector("td[id]")) break;
            await sleep(50);
        }
        if(!currentList || !currentList.members.length){
            console.log("No data in table");
            return;
        }

const tableData = getTableData();
if(!tableData.length){
            console.log("No table data");
            return;
        }

        const data = tableData[0];  // ALWAYS fresh values

        let dateVal = (data.date || "").trim();     // example: "3/4"
        let peopleVal = (data.people || "").trim(); // example: "2"
        let timeVal = (data.time || "").trim();     // example: "0900"

        // ❌ if anything missing → stop
        if(!dateVal || !peopleVal || !timeVal){
            console.log("Slot data missing → skipping slot selection");
            return;
        }

        console.log("Selecting slot:", dateVal, peopleVal, timeVal);
        // ======================
        // STEP 1: DATE
        // ======================
        // ======================
        // STEP 1: DATE (FINAL FIX)
        // ======================
        // ======================
        // STEP 1: DATE (NEW FIX)
        // ======================
        let dateEl = null;

        dateVal = dateVal.replace(/^0+/, "").trim();

        for(let i = 0; i < 40; i++){

            const allDates =
            Array.from(document.querySelectorAll("td[id]"));

            dateEl = allDates.find(td => {

                const id = td.id?.trim();

                if(id !== dateVal) return false;

                const style = window.getComputedStyle(td);

                return (
                    style.pointerEvents !== "none" &&
                    td.offsetParent !== null
                );
            });

            if(dateEl) break;

            await sleep(500);
        }

        if(!dateEl){

            console.log("Date not found:", dateVal);

            return;
        }

        const innerDiv = dateEl.querySelector("div") || dateEl;

        innerDiv.scrollIntoView({
            block: "center"
        });

        await sleep(300);

        ["mousedown","mouseup","click"].forEach(type => {

            innerDiv.dispatchEvent(
                new MouseEvent(type,{
                    bubbles:true,
                    cancelable:true,
                    view:window
                })
            );
        });

        console.log("Date clicked:", dateVal);
        // ======================
        // ======================
        // STEP 2: PEOPLE (BASED ON REAL WORKING XPATH)
        // ======================
        // ======================
        // STEP 2: PEOPLE
        // ======================

        let peopleDropdown = null;

        // Find visible dropdown-like controls
        for(let i=0;i<20;i++){

            const dropdowns = Array.from(
                document.querySelectorAll(
                    '[role="combobox"], [aria-haspopup="listbox"], input[readonly]'
                )
            ).filter(el => {

                return (
                    el.offsetParent !== null &&
                    el.getBoundingClientRect().height > 20
                );
            });

            console.log(
                "Visible dropdowns:",
                dropdowns.length
            );

            // Usually PEOPLE is first visible combobox after date selection
            if(dropdowns.length){

                peopleDropdown = dropdowns[0];

                break;
            }

            await sleep(500);
        }

        if(!peopleDropdown){

            console.log(
                "People dropdown trigger not found"
            );

            return;
        }

        peopleDropdown.scrollIntoView({
            block:"center"
        });

        await sleep(300);

        // REAL USER EVENTS
        ["pointerdown","mousedown","mouseup","click"].forEach(type => {

            peopleDropdown.dispatchEvent(
                new MouseEvent(type,{
                    bubbles:true,
                    cancelable:true,
                    view:window
                })
            );
        });

        console.log(
            "People dropdown clicked"
        );

        await sleep(1000);

        // ======================
        // STEP 3: SELECT PEOPLE OPTION
        // ======================

        let option = null;

        for(let i=0;i<20;i++){

            const options = Array.from(
                document.querySelectorAll(
                    'li, [role="option"]'
                )
            ).filter(el => {

                return (
                    el.innerText?.trim() === peopleVal &&
                    el.offsetParent !== null
                );
            });

            console.log(
                "People options:",
                options.map(o => o.innerText)
            );

            if(options.length){

                option = options[0];

                break;
            }

            await sleep(300);
        }

        if(!option){

            console.log(
                "People option not found:",
                peopleVal
            );

            return;
        }

        option.scrollIntoView({
            block:"center"
        });

        await sleep(200);

        ["pointerdown","mousedown","mouseup","click"].forEach(type => {

            option.dispatchEvent(
                new MouseEvent(type,{
                    bubbles:true,
                    cancelable:true,
                    view:window
                })
            );
        });

        console.log(
            "People selected:",
            peopleVal
        );

        await sleep(1000);

        // STEP 3: TIME SLOT
        // ======================

        let timeBtn = null;

        for(let i=0;i<20;i++){

            timeBtn = document.querySelector(
                `button[value="${timeVal}"]`
            );

            if(
                timeBtn &&
                !timeBtn.disabled &&
                timeBtn.offsetParent !== null
            ){
                break;
            }

            await sleep(500);
        }

        if(!timeBtn){

            console.log(
                "Time slot not found:",
                timeVal
            );

            return;
        }

        ["pointerdown","mousedown","mouseup","click"].forEach(type => {

            timeBtn.dispatchEvent(
                new MouseEvent(type,{
                    bubbles:true,
                    cancelable:true,
                    view:window
                })
            );
        });

        console.log(
            "Time selected:",
            timeVal
        );

        await sleep(1000);

        //-=========================
        let slotLoaded = false;

        for(let i=0;i<30;i++){

            const peopleDropdown =
            document.querySelector('input[readonly]');

            const timeButtons =
            document.querySelectorAll('button[value]');

            if(peopleDropdown && timeButtons.length){
                slotLoaded = true;
                break;
            }

            await sleep(500);
        }

        if(!slotLoaded){
            console.log("Slots failed to load");
            return;
        }

        // ======================
        // STEP 4: CONTINUE
        // ======================
        let continueBtn = Array.from(document.querySelectorAll("button"))
        .find(b => /continue/i.test(b.innerText) && !b.disabled);

        if(continueBtn){
            continueBtn.click();
        } else {
            console.log("Continue button not found");
        }
    }
    // =======================
    // GET TABLE DATA (REQUIRED FIX)
    // =======================

    // --- Autofill and Form Logic ---
    async function autofill(){

        if(!currentList)return;
        const nameInputs=document.querySelectorAll('input[name="name"],input[formcontrolname="name"],input[name="fname"]');
        const ageInputs=document.querySelectorAll('input[name="age"],input[formcontrolname="age"]');
        const genderInputs=document.querySelectorAll('input[name="gender"],select[name="gender"]');
        const idTypeInputs=document.querySelectorAll('input[name="idType"],input[formcontrolname="photoIdType"],select[name="photoIdType"], input[name="photoIdType"]');
        const idNumberInputs=document.querySelectorAll('input[name="idNumber"],input[name="idProofNumber"],input[formcontrolname="idProofNumber"]');
        const allInputs=document.querySelectorAll("input.floating-input,input[label]");
        function findByLabel(text){return Array.from(allInputs).find(el=>((el.getAttribute("label")||"")+" "+(el.name||"")).toLowerCase().includes(text.toLowerCase()));}
        for(let i=0;i<currentList.members.length;i++){let member=currentList.members[i];
            if(nameInputs[i])setValue(nameInputs[i],member.name||"");
            if(ageInputs[i])setValue(ageInputs[i],member.age||"");
            await pick(genderInputs[i],member.gender||"");
            await pick(idTypeInputs[i],member.aadhar?"Aadhaar Card":"");
            if(idNumberInputs[i])setValue(idNumberInputs[i],member.aadhar||"");}
            const first=currentList.members[0]||{};
        setValue(findByLabel("email"),first.email||"");
        setValue(findByLabel("city"),first.city||"");
        setValue(findByLabel("state"),first.state||"");
        setValue(findByLabel("country"),first.country||"");
        setValue(findByLabel("pin"),first.pincode||"");
        setValue(findByLabel("gothram"),first.gotram||"");

    }

    async function autoContinue(){

        let b =
        document.querySelector('button.virtualReviewDetails_continue-btn__5468H') ||
        document.querySelector('button.pilgrimDetails_continue-btn__waupr');

        if (!b) {
            b = Array.from(document.querySelectorAll("button")).find(btn => /continue/i.test(btn.innerText) && !btn.disabled && btn.offsetParent !== null);
        }

        if(b && !b.disabled && b.offsetParent !== null){
            b.click();
            await sleep(100);
        }
    }

  async function clickPayNow(){
      let firstPay = Array.from(document.querySelectorAll("button"))
      .find(b => b.innerText && b.innerText.trim().toLowerCase() === "pay now" && !b.disabled);

      if(firstPay){
          firstPay.click();
      }
  }
    // --- End Autofill and Form Logic ---


    // --- UI Utilities ---
    function mkBtn(text,fn,color="#2196f3",padding="6px 12px",fontsize="14px"){
        let b=document.createElement("button");
        b.textContent=text;
        b.style.cssText=`padding:${padding};border-radius:6px;border:none;background:${color};color:#fff;cursor:pointer;font-size:${fontsize};`;
        b.onclick=fn;
        return b;
    }

    // NEW: Settings Panel (Opened by 3 dots)
    function openSettingsPanel(originWrap) {
        const sWrap = document.createElement("div");
        sWrap.id = "ttd-settings-panel";
        sWrap.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background: #fff; border: 2px solid #000; border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3); padding: 15px; z-index: 1000000;
        width: 250px; font-family: sans-serif;
        `;
        sWrap.innerHTML = `
        <h4 style="margin-top:0; border-bottom: 1px solid #ccc; padding-bottom: 5px;">Settings & Account</h4>
        <div id="settings-content"></div>
        <button style="position:absolute; top:5px; right:5px; background:none; border:none; font-size:18px; cursor:pointer;" onclick="this.parentNode.remove()">&times;</button>
        `;

        const content = sWrap.querySelector("#settings-content");

        // Helper for Menu Item
        function mkMenuItem(text, fn, color="#333") {
            const div = document.createElement("div");
            div.style.cssText = `
            padding: 8px 0; border-bottom: 1px dotted #eee; cursor: pointer; color: ${color};
            font-size: 14px; transition: background 0.1s;
            `;
            div.textContent = text;
            div.onmouseover = () => div.style.background = '#f0f0f0';
            div.onmouseout = () => div.style.background = 'none';
            div.onclick = () => { sWrap.remove(); fn(); }; // Close panel after click
            return div;
        }

        // Helper for Toggle Switch
        function mkToggle(text, key, updateFn) {
            const id = 'toggle-' + key;
            const checked = settings[key] ? 'checked' : '';
            const div = document.createElement("div");
            div.style.cssText = `display:flex; justify-content:space-between; align-items:center; padding: 8px 0; border-bottom: 1px dotted #eee; font-size: 14px;`;

            div.innerHTML = `<span>${text}</span>
            <label class="switch" style="position:relative; display:inline-block; width:36px; height:20px;">
            <input type="checkbox" id="${id}" ${checked} style="opacity:0; width:0; height:0;">
            <span class="slider round" style="position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background:#ccc; border-radius:20px; transition:.4s;"></span>
            </label>`;

            const style = document.createElement('style');
            style.textContent = `
            .switch input:checked + .slider { background-color: #4CAF50; }
            .switch input:focus + .slider { box-shadow: 0 0 1px #4CAF50; }
            .switch input:checked + .slider:before { transform: translateX(16px); }
            .switch .slider:before { position:absolute; content:""; height:16px; width:16px; left:2px; bottom:2px; background-color:white; border-radius:50%; transition:.4s; }
            `;
            sWrap.appendChild(style);

            const input = div.querySelector(`#${id}`);
            input.onchange = (e) => {
                settings[key] = e.target.checked;
                localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
                updateFn();
            };
            return div;
        }

        // --- Plan Selection Box (RENEW/BUY PLAN - MOVED FROM MAIN PANEL) ---
        const planSelectBox = document.createElement("div");
        planSelectBox.style.cssText = `padding: 8px 0; border-bottom: 1px solid #ccc; background: #f9f9f9; padding: 10px; border-radius: 4px; margin-bottom: 10px;`;
        planSelectBox.innerHTML = `
        <span style="font-weight: bold; display: block; margin-bottom: 5px; color: #2196F3;">\u2714 Renew/Buy Plan</span>
        <div style="display: flex; gap: 5px; align-items: center;">
        <select id="settings-plan-select" style="padding: 4px; flex-grow: 1; border: 1px solid #ccc; border-radius: 4px;"></select>
        <button id="settings-plan-activate" style="padding: 4px 8px; border: none; background: #4CAF50; color: white; border-radius: 4px; cursor: pointer; font-size: 12px;">Activate</button>
        </div>
        `;

        const planSelect = planSelectBox.querySelector("#settings-plan-select");
        const activateBtn = planSelectBox.querySelector("#settings-plan-activate");

        const plans = ["30 Days", "60 Days", "90 Days", "365 Days"];
        plans.forEach(p => {
            let o = document.createElement("option");
            o.value = p.split(" ")[0];
            o.textContent = p;
            if(o.value === selectedPlan) o.selected = true;
            planSelect.appendChild(o);
        });

        activateBtn.onclick = () => {
            selectedPlan = planSelect.value;
            const days = parseInt(selectedPlan);

            const expiryMs = Date.now() + (days * 24 * 60 * 60 * 1000);

            auth.expiryTimestamp = expiryMs;
            auth.loggedIn = true;
            localStorage.setItem(AUTH_KEY, JSON.stringify(auth));

            alert(`Plan activated for ${selectedPlan} days. Expires on: ${new Date(expiryMs).toLocaleDateString()}.`);
            updateManagerHeader(originWrap); // Update the expiry status in the main panel
            sWrap.remove(); // Close settings panel
        };

        content.appendChild(planSelectBox); // Add plan selection first
        // --- End Plan Selection Box ---


        // 1. Logout (Kept in Settings Panel)
        content.appendChild(mkMenuItem("Logout", () => {
            auth.loggedIn = false;
            localStorage.setItem(AUTH_KEY, JSON.stringify(auth));
            originWrap.remove();
            openAuthManager();
        }, "#F44336"));

        // 2. Change Password (Placeholder)
        content.appendChild(mkMenuItem("Change Password", () => {
            alert("This is a local storage feature. To 'change' your password, simply create a new account with the same email in the Login/Create panel.");
        }, "#795548"));

        // 3. Identity/Email Info
        content.appendChild(mkMenuItem(`Identity: ${auth.email}`, () => {
            alert(`Logged in as: ${auth.email}\nSubscription Status: ${getExpiryStatus()}`);
        }, "#607D8B"));

        // --- Toggles ---

        // 4. Show lower toolbar in web browsers (Controls visibility)
        content.appendChild(mkToggle(
            "Show Controls (Toolbar)",
                                     "showLowerToolbar",
                                     () => updateManagerHeader(originWrap) // Update main panel display
        ));


        document.body.appendChild(sWrap);
    }

    // --- Authentication UI with Forget Password ---
    function openAuthManager(){
        if(window.__ttdManager && window.__ttdManager.id === 'ttd-manager') window.__ttdManager.remove(); // Close manager if open

        wrap.id="ttd-auth-manager";
        wrap.style.cssText="position:fixed;top:20%;left:50%;transform:translateX(-50%);background:#fff;border:2px solid #111;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.2);padding:20px;z-index:999999;font-family:sans-serif;max-width:300px;";
        wrap.innerHTML = '';
        document.body.appendChild(wrap);
        wrap.innerHTML=`
        <h3 style="margin-top:0;text-align:center;">TTD Shortcut - Login/Create</h3>
        <input type="email" id="ttd-email" placeholder="Email" style="width:100%;padding:10px;margin-bottom:10px;border:1px solid #ccc;border-radius:4px;" value="${auth.email || ''}">
        <input type="password" id="ttd-password" placeholder="Password" style="width:100%;padding:10px;margin-bottom:10px;border:1px solid #ccc;border-radius:4px;">
        <div style="display:flex;justify-content:space-between;gap:10px;">
        <button id="ttd-create" style="flex:1;padding:10px;border-radius:4px;border:none;background:#FF9800;color:#fff;cursor:pointer;">Create Account</button>
        <button id="ttd-login" style="flex:1;padding:10px;border-radius:4px;border:none;background:#4CAF50;color:#fff;cursor:pointer;">Login</button>
        </div>
        <p id="ttd-forgot" style="text-align:right;margin-top:10px;font-size:12px;cursor:pointer;color:#2196F3;text-decoration:underline;">Forgot Password?</p>

        <button id="ttd-close" style="position:absolute;top:5px;right:5px;background:none;border:none;font-size:18px;cursor:pointer;">&times;</button>
        `;

        document.getElementById('ttd-close').onclick = () => wrap.remove();

        document.getElementById('ttd-forgot').onclick = () => {
            const email = document.getElementById('ttd-email').value.trim();
            if(auth.email && auth.email === email){
                alert("Password reset link sent to your registered email: " + email);
            } else {
                alert("Please enter the registered email address to receive a password reset link.");
            }
        };

        function getCreds(){
            return {
                email: document.getElementById('ttd-email').value.trim(),
            password: document.getElementById('ttd-password').value.trim()
            };
        }

        document.getElementById('ttd-create').onclick = () => {
            const {email, password} = getCreds();
            if(!email || password.length < 6){
                alert("Please enter a valid email and a password of at least 6 characters.");
                return;
            }
            if(auth.email && auth.email !== email){
                if(!confirm("An account already exists. Overwrite?")){
                    return;
                }
            }
            const currentExpiry = (auth.email === email && auth.expiryTimestamp) ? auth.expiryTimestamp : null;

            auth = {email, password, loggedIn: false, expiryTimestamp: currentExpiry};
            localStorage.setItem(AUTH_KEY, JSON.stringify(auth));
            alert("Account Created! Now Log in.");
        };

        document.getElementById('ttd-login').onclick = () => {
            const {email, password} = getCreds();
            if(auth.email === email && auth.password === password){
                auth.loggedIn = true;
                localStorage.setItem(AUTH_KEY, JSON.stringify(auth));
                wrap.remove();
                if (isExpired()) {
                    alert("Login Successful, but your subscription has expired. Please choose a plan in the manager panel to continue.");
                }
                openManager();
            } else {
                alert("Invalid Email or Password. Try creating an account first.");
            }
        };
    }


    // --- Main Manager UI (Modified) ---
    function openManager(){
        let isMax = false, oldPosition = {};
        if(document.getElementById('ttd-auth-manager')) {
            document.getElementById('ttd-auth-manager').remove();
        }

        // Remove if any existing panel is present
        if(window.__ttdManager){window.__ttdManager.remove();}
        window.__ttdManager=document.createElement("div");
        const wrap=window.__ttdManager;
        document.body.appendChild(wrap);

            wrap.id="ttd-manager";
            wrap.style.cssText="position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#fff;border:2px solid #111;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.2);padding:12px;z-index:999999;max-height:80%;max-width:96vw;overflow:auto;font-family:sans-serif;font-size:14px;cursor:move;";

                   wrap.style.resize = "both";
        wrap.style.overflow = "auto";
        // Restore saved position/size
        let stored = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
        if (stored.windowPos) {
            wrap.style.top = stored.windowPos.top;
            wrap.style.left = stored.windowPos.left;
            wrap.style.transform = "none";
        }
        if (stored.windowSize) {
            wrap.style.width = stored.windowSize.width;
            wrap.style.height = stored.windowSize.height;
        }

        // **HEADER:** Holds email, expiry status, and control buttons
        const header=document.createElement("div");
        header.id="ttd-manager-header";
        header.style.cssText="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;font-weight:700;font-size:16px;cursor:move;";
        // Drag logic
        let isDragging = false, startX, startY, startLeft, startTop;
        header.onmousedown = function(e) {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            const rect = wrap.getBoundingClientRect();
            startLeft = rect.left;
            startTop = rect.top;
            document.onmousemove = function(e) {
                if (!isDragging) return;
                // Update position as mouse moves
                wrap.style.left = (startLeft + (e.clientX - startX)) + "px";
                wrap.style.top  = (startTop + (e.clientY - startY)) + "px";
                wrap.style.transform = "none";  // cancel the initial centering transform
            };
            document.onmouseup = function() {
                if (!isDragging) return;
                isDragging = false;
                document.onmousemove = null;
                document.onmouseup = null;
                // Save new position/size
                settings.windowPos = {top: wrap.style.top, left: wrap.style.left};
                settings.windowSize = {width: wrap.offsetWidth + "px", height: wrap.offsetHeight + "px"};
                localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
            };
        };

        // Left side: Title/Email & Expiry Status
        const titleStatusWrap = document.createElement("div");
        titleStatusWrap.style.display = "flex";
        titleStatusWrap.style.flexDirection = "column";

        const titleSpan = document.createElement("span");
        titleSpan.id = "ttd-user-email";
        titleSpan.textContent = 'TTD Shortcut (' + auth.email + ')';
        titleStatusWrap.appendChild(titleSpan);

        const expirySpan = document.createElement("span");
        expirySpan.id = "ttd-expiry-status";
        expirySpan.style.cssText = "font-size:12px;margin-left:0px;";
        titleStatusWrap.appendChild(expirySpan);
        header.appendChild(titleStatusWrap);

        // Right side: Control Buttons
        const btnWrap=document.createElement("div");
        btnWrap.style.display="flex"; btnWrap.style.gap="6px";

        // 3 dots button for settings
        const settingsBtn = mkBtn("\u22EE", () => openSettingsPanel(wrap), "#2196F3", "2px 6px", "18px");
        btnWrap.appendChild(settingsBtn);

        // LOGOUT BUTTON REMOVED FROM MAIN PANEL HEADER

        const minBtn=mkBtn("\u2501",()=>{
            minimized=!minimized;
            const table = wrap.querySelector("table");
            const tbody = wrap.querySelector("tbody");
            // Removed planSelectWrap visibility logic as it's no longer here

            // Hide only the data (table)
            if(tbody) tbody.style.display=minimized?"none":"";
            if(table) table.style.display=minimized?"none":"";

            // Main controls and small controls remain visible and functional
            // Note: Their visibility is controlled by 'showLowerToolbar' setting

            minBtn.style.background=minimized?"#FFC107":"#757575";
        },"#757575","2px 6px","14px");
        btnWrap.appendChild(minBtn);
        // Maximize / Restore button
        const maxBtn = mkBtn("\u2752", () => {
            if (!isMax) {
                // Save current position/size
                oldPosition = {
                    top: wrap.style.top,
                    left: wrap.style.left,
                    width: wrap.style.width,
                    height: wrap.style.height
                };
                // Expand to full viewport
                wrap.style.top = "0";
                wrap.style.left = "0";
                wrap.style.width = "100%";
                wrap.style.height = "100%";
            } else {
                // Restore previous position/size
                wrap.style.top    = oldPosition.top;
                wrap.style.left   = oldPosition.left;
                wrap.style.width  = oldPosition.width;
                wrap.style.height = oldPosition.height;
            }
            isMax = !isMax;
        }, "#757575", "2px 6px", "14px");
        btnWrap.appendChild(maxBtn);

        const closeBtn=mkBtn("\u2715",()=>wrap.remove(),"#f44336","2px 6px","14px");
        btnWrap.appendChild(closeBtn);

        header.appendChild(btnWrap);
        wrap.appendChild(header);
        // FORCE DEFAULT MINIMIZED VIEW
        setTimeout(() => {
            const table = wrap.querySelector("table");
            const tbody = wrap.querySelector("tbody");

            if(tbody) tbody.style.display="none";
            if(table) table.style.display="none";

            const minBtn = header.querySelector("button:nth-child(2)");
            if(minBtn) minBtn.style.background="#FFC107";
        }, 0);

        // Draggable logic attached to the header
        let pos1=0,pos2=0,pos3=0,pos4=0;
        header.onmousedown=function(e){e.preventDefault();pos3=e.clientX;pos4=e.clientY;document.onmouseup=closeDrag;document.onmousemove=drag;};
        function drag(e){
            e.preventDefault();

            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;

            // VERY IMPORTANT: remove initial positioning ONLY ON FIRST DRAG
            if (wrap.style.transform !== "none") {
                wrap.style.transform = "none";
                wrap.style.bottom = "auto";
            }

            wrap.style.top = (wrap.offsetTop - pos2) + "px";
            wrap.style.left = (wrap.offsetLeft - pos1) + "px";
        }
        function closeDrag(){document.onmouseup=null;document.onmousemove=null;}

        // --- Premium Plan Selection (Renewal/Activation) - REMOVED FROM MAIN PANEL ---
        // This section is now in openSettingsPanel.
        // --- End Premium Plan Selection ---

        const mainControls=document.createElement("div");
        mainControls.id = "main-controls";
        mainControls.style.cssText="display:flex;justify-content:center;flex-wrap:wrap;gap:6px;margin-bottom:12px";
        wrap.appendChild(mainControls);

        // Apply initial visibility setting
        mainControls.style.display = settings.showLowerToolbar ? 'flex' : 'none';

        // --- Main Controls ---
        mainControls.appendChild(mkBtn("Auto Fill",autofill,"#FFEB3B"));
        mainControls.appendChild(mkBtn("Continue",autoContinue,"#FF9800"));
        mainControls.appendChild(mkBtn("Run All",async()=>{
            if (isExpired()) {
                alert("Run All failed: Your subscription is expired. Please renew your plan.");
                return;
            }
           // await selectSlotDetails();   // NEW STEP
           //await selectSlotDetailsSkip();
           // await sleep(300);
            //await autofill();
            //await autoContinue();
            //await autoContinue();
            //await sleep(300);
            //await clickPayNow();
            await runAutomationSafe();

        },"#4CAF50"));

        function validateRow(row){let age=parseInt(row.querySelector("td[data-key='age']").textContent.trim());let aadhaar=row.querySelector("td[data-key='aadhar']").textContent.trim();let valid=true;if(isNaN(age)||age<13||age>99){row.querySelector("td[data-key='age']").style.border="2px solid red";valid=false;}else{row.querySelector("td[data-key='age']").style.border="";}if(!/^\d{12}$/.test(aadhaar)){row.querySelector("td[data-key='aadhar']").style.border="2px solid red";valid=false;}else{row.querySelector("td[data-key='aadhar']").style.border="";}return valid;}
        function getManagerTableData(){
        //"pavan commented and added below line"    const cols=["name","age","gender","aadhar","email","city","state","country","pincode","gotram"];
const cols=["date","people","time","name","age","gender","aadhar","email","city","state","country","pincode","gotram","upi"];
const tbody = wrap.querySelector("tbody");
            if (!tbody) return [];
            return Array.from(tbody.querySelectorAll("tr")).map(tr=>{
                let obj={};
                tr.querySelectorAll("td").forEach((x,i)=>{obj[cols[i]]=(x.querySelector("select")?x.querySelector("select").value:x.textContent.trim());});
                return obj;
            });
        }

        mainControls.appendChild(mkBtn("Save",()=>{
            const tbody = wrap.querySelector("tbody");
            if(!currentList || !tbody) return;
            const allValid=Array.from(tbody.querySelectorAll("tr")).every(validateRow);
            if(!allValid){alert("Fix errors!");return;}
            currentList.members=getManagerTableData();
            const idx=lists.findIndex(l=>l.listName===currentList.listName);
            if(idx>=0){lists[idx]=currentList;}else{lists.push(currentList);}
            localStorage.setItem(STORAGE_KEY,JSON.stringify(lists));
            alert("Saved");
            renderDropdown();
        },"#9C27B0"));
        mainControls.appendChild(mkBtn("Pay Now",clickPayNow,"#F44336"));

        /* SIDE CONTROLS */
        const smallControls=document.createElement("div");
        smallControls.id = "small-controls";
        smallControls.style.cssText="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px";
        wrap.appendChild(smallControls);

        // Apply initial visibility setting
        smallControls.style.display = settings.showLowerToolbar ? 'flex' : 'none';


        const listSelect=document.createElement("select");
        listSelect.style.padding="4px"; listSelect.style.minWidth="120px";
        smallControls.appendChild(listSelect);

        function renderDropdown(){listSelect.innerHTML="";lists.forEach(l=>{let o=document.createElement("option");o.value=l.listName;o.textContent=l.listName;listSelect.appendChild(o);});if(lists.length>0){listSelect.value=lists[0].listName;loadList(lists[0].listName);}}
        function loadList(name){currentList=lists.find(l=>l.listName===name)||{listName:name,members:[]};renderTable(currentList.members);}
        listSelect.onchange=()=>loadList(listSelect.value);

        smallControls.appendChild(mkBtn("Add",()=>{if(!currentList)return;

            currentList.members.push({
            date:"",
            people:"",
            time:"",
            name:"",
            age:"",
            gender:"Male",
            aadhar:"",
            email:"",
            city:"Hyderabad",
            state:"Telangana",
            country:"India",
            pincode:"500040",
            gotram:"",
            upi:""
        });
        renderTable(currentList.members);},"#4CAF50","4px 8px","12px"));
        smallControls.appendChild(mkBtn("New",()=>{const name=prompt("New list name:");if(!name)return;lists.push({listName:name,members:[]});localStorage.setItem(STORAGE_KEY,JSON.stringify(lists));renderDropdown();},"#FF9800","4px 8px","12px"));
        smallControls.appendChild(mkBtn("Rename",()=>{if(!currentList)return;const newName=prompt("Rename:",currentList.listName);if(!newName)return;const idx=lists.findIndex(l=>l.listName===currentList.listName);if(idx>=0){lists[idx].listName=newName;currentList.listName=newName;localStorage.setItem(STORAGE_KEY,JSON.stringify(lists));renderDropdown();}},"#FFC107","4px 8px","12px"));
        smallControls.appendChild(mkBtn("Delete",()=>{if(!currentList)return;if(!confirm("Delete list?"))return;lists=lists.filter(l=>l!==currentList);localStorage.setItem(STORAGE_KEY,JSON.stringify(lists));currentList=lists[0]||null;renderDropdown();},"#F44336","4px 8px","12px"));
        smallControls.appendChild(mkBtn("Export",()=>{if(!currentList)return;const dataStr=JSON.stringify(currentList.members,null,2);const blob=new Blob([dataStr],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=currentList.listName+".json";a.click();URL.revokeObjectURL(url);},"#795548","4px 8px","12px"));
        smallControls.appendChild(mkBtn("Import",()=>{const inp=document.createElement("input");inp.type="file";inp.accept=".json";inp.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=o=>{currentList.members=JSON.parse(o.target.result);renderTable(currentList.members);};r.readAsText(f);};inp.click();},"#607D8B","4px 8px","12px"));

        /* TABLE */
        const table=document.createElement("table");
        table.style.cssText="border-collapse:collapse;width:100%;margin-top:8px;";
        const thead=document.createElement("thead");
        const trh=document.createElement("tr");
       //"pavan commented for below line" const cols=["name","age","gender","aadhar","email","city","state","country","pincode","gotram"];
        const cols=["date","people","time","name","age","gender","aadhar","email","city","state","country","pincode","gotram","upi"];
        cols.concat(["Actions"]).forEach(c=>{let th=document.createElement("th");th.textContent=c;th.style.cssText="border-bottom:1px solid #ddd;padding:6px;text-align:left;background:#fafafa";trh.appendChild(th);});
        thead.appendChild(trh);table.appendChild(thead);

        const tbody=document.createElement("tbody");
        tbody.id = "ks-manager-table";
        table.appendChild(tbody);
        wrap.appendChild(table);

        function renderTable(members){
            tbody.innerHTML="";
            members.forEach((m,idx)=>{
                const tr=document.createElement("tr");
                cols.forEach(c=>{
                    const td=document.createElement("td");
                    td.dataset.key=c;
                    td.style.cssText="border-bottom:1px solid #eee;padding:6px;min-width:80px;background:#BBDEFB";
                    if(c==="gender"){
                        const s=document.createElement("select");
                        ["Male","Female"].forEach(o=>{let op=document.createElement("option");op.value=o;op.textContent=o;if(m.gender===o)op.selected=true;s.appendChild(op);});
                        s.onchange=()=>m.gender=s.value;
                        td.appendChild(s);
                    }else{
                        td.contentEditable="true";
                        td.textContent=m[c]||"";
                    }
                    tr.appendChild(td);
                });
                const act=document.createElement("td");
                act.style.cssText="white-space:nowrap;border-bottom:1px solid #eee;padding:6px";
                act.appendChild(mkBtn("\u25B2",()=>{if(idx>0)[members[idx-1],members[idx]]=[members[idx],members[idx-1]];renderTable(members);},"#B3E5FC","4px 8px","12px"));
                act.appendChild(mkBtn("\u25BC",()=>{if(idx<members.length-1)[members[idx+1],members[idx]]=[members[idx],members[idx+1]];renderTable(members);},"#B3E5FC","4px 8px","12px"));
                act.appendChild(mkBtn("\u2398",()=>{members.splice(idx+1,0,JSON.parse(JSON.stringify(members[idx])));renderTable(members);},"#B3E5FC","4px 8px","12px"));
                act.appendChild(mkBtn("\u2715",()=>{if(confirm("Delete?")){members.splice(idx,1);renderTable(members);}},"#F8BBD0","4px 8px","12px"));
                tr.appendChild(act);tbody.appendChild(tr);
            });
        }

        renderDropdown();
        renderTable(currentList?currentList.members:[]);
        updateManagerHeader(wrap);
    }


    // *** NEW: Shortcut Key Handler (Add this block before the final })();) ***
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

        if (request.action === "runAutofillShortcut") {

            // This logic mimics the 'Run All' button click
            async function runAllShortcut() {


               // await selectSlotDetails();   // NEW STEP
               // await selectSlotDetailsSkip();
               // await sleep(300);
                //await autofill();
                //await autoContinue();
                //await autoContinue();
                //await clickPayNow();
                await runAutomationSafe();
            }

            runAllShortcut();
        }

    });
    // *** END Shortcut Key Handler ***
//
    // *** MAIN ENTRY POINT LOGIC - MODIFIED TO ALWAYS OPEN IF LOGGED IN ***
    if(auth.loggedIn && auth.email && auth.password){
        if (!IS_REVIEW_MODE && isExpired()) { // Check expiry only if NOT in review mode
            alert("Your subscription for " + auth.email + " has expired. Please select a plan to renew in the Settings menu (\u22EE).");
        }

        // This ensures the panel always opens when the script runs (i.e., on icon click/page load).
        openManager();
        handlePaymentPage();
    } else {
        // If not logged in, always show auth screen to allow login/create account
       // openAuthManager();
        // This ensures the panel always opens when the script runs (i.e., on icon click/page load).
        openManager();
        handlePaymentPage();
    }

    // =========================
    // AUTO UPI PAYMENT HANDLER
    // =========================
    let paymentHandled = false;
    async function handlePaymentPage(){

        if(!document.body.innerText.includes("Choose the payment method below")){
            return;
        }

        console.log("Payment page detected");

        const upiValue = getCurrentUpiValue();

        console.log("UPI from table:", upiValue);

        // =========================
        // QR FLOW
        // =========================
        if(!upiValue){

            console.log("UPI empty → QR flow");

            let generateBtn = null;

            for(let i = 0; i < 20; i++){

                generateBtn = Array.from(
                    document.querySelectorAll("button")
                ).find(btn =>
                btn.textContent?.trim() === "Generate"
                );

                if(generateBtn){
                    break;
                }

                await sleep(500);
            }

            if(!generateBtn){

                console.log("Generate button not found");

                return;
            }
            console.log("Found Generate:", generateBtn);


            generateBtn.click();

            console.log("Generate clicked");

            paymentHandled = true;

            return;
        }
        // =========================
        // UPI FLOW
        // =========================

        let upiTab = Array.from(
            document.querySelectorAll("div")
        ).find(el =>
        el.innerText &&
        el.innerText.trim() === "UPI"
        );

        if(upiTab){
            upiTab.click();
        }

        let upiInput = null;

        for(let i=0;i<20;i++){

            upiInput = document.querySelector(
                'input[type="text"]'
            );

            if(upiInput) break;

            await sleep(500);
        }

        if(!upiInput){

            console.log("UPI input not found");

            return;
        }

        upiInput.focus();

        setValue(upiInput, upiValue);

        await sleep(1000);

        for(let i=0;i<5;i++){

            let btn = Array.from(
                document.querySelectorAll("button")
            ).find(b =>
            b.innerText &&
            b.innerText.trim().toLowerCase() === "pay now" &&
            !b.disabled
            );

            if(btn){

                btn.click();

                console.log("Final Pay Clicked");

                paymentHandled = true;

                return;
            }

            await sleep(1000);
        }
    }
    // =======================
    // AUTO PAYMENT HANDLER
    // =======================


    // =======================
    // AUTO PAYMENT WATCHER (FIX)
    // =======================

    setInterval(() => {

        if(paymentHandled){
            return;
        }

        if(
            document.body.innerText.includes(
                "Choose the payment method below"
            )
        ){

            console.log(
                "Payment page detected by watcher"
            );

            handlePaymentPage();
        }

    }, 1000);

    })();
