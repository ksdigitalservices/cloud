import base64
import subprocess

# PEM file path
pem_file = "1.1.4_0.pem"

# Step 1: Extract the public key in DER format
subprocess.run(f"openssl rsa -pubout -in {pem_file} -outform DER -out temp.pub", shell=True, check=True)

# Step 2: SHA256 hash of the public key
subprocess.run("openssl dgst -sha256 -binary temp.pub > temp.sha256", shell=True, check=True)

# Step 3: Read hash and convert to Chrome ID
with open("temp.sha256", "rb") as f:
    hash_bytes = f.read()

chrome_id = base64.b32encode(hash_bytes).decode("utf-8").lower().rstrip("=")
chrome_id = chrome_id[:32]  # Chrome uses first 32 chars

print("Chrome Extension ID:", chrome_id)
